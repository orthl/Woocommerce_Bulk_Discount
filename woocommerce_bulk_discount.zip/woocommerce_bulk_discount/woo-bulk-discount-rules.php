<?php
/*
Plugin Name: Woo Bulk Discount Rules
Description: Discount rules based on product, category, or shipping class IDs with priority handling.
Version: 1.0
Author: Lucas Orth
*/

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'wmr_add_admin_menu');
add_action('admin_init', 'wmr_register_settings');

function wmr_add_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Bulk Discounts',
        'Bulk Discounts',
        'manage_woocommerce',
        'wmr_mengenrabatte',
        'wmr_settings_page'
    );
}

function wmr_register_settings() {
    register_setting('wmr_settings_group', 'wmr_discount_rules', [
        'sanitize_callback' => 'wmr_validate_rules'
    ]);
}

function wmr_validate_rules($rules) {
    $cleaned = [];
    $ids_seen = [];

    foreach ($rules as $index => $rule) {
        if (!empty($rule['delete'])) continue;

        $required = ['order', 'type', 'id', 'qty', 'discount'];
        foreach ($required as $field) {
            if (!isset($rule[$field]) || $rule[$field] === '') {
                add_settings_error('wmr_discount_rules', 'missing_field_' . $field, "Fehlendes Feld '$field' in Regel #$index");
                return get_option('wmr_discount_rules', []);
            }
        }

        $ids = array_map('trim', explode(',', $rule['id']));
        foreach ($ids as $id) {
            if (in_array($id, $ids_seen)) {
                add_settings_error('wmr_discount_rules', 'duplicate_id', "Die ID $id ist mehrfach vergeben.");
                return get_option('wmr_discount_rules', []);
            }
            $ids_seen[] = $id;
        }

        if (floatval($rule['discount']) <= 0 || fmod(floatval($rule['discount']), 0.5) !== 0.0) {
            add_settings_error('wmr_discount_rules', 'invalid_discount', "Discount muss positiv und in 0,50€-Schritten angegeben werden.");
            return get_option('wmr_discount_rules', []);
        }

        $cleaned[] = $rule;
    }

    return array_values($cleaned);
}

function wmr_settings_page() {
    $rules = get_option('wmr_discount_rules', []);
    settings_errors('wmr_discount_rules');
    ?>
    <div class="wrap">
        <h1>Quantitynrabatt-Rules</h1>
        <form method="post" action="options.php">
            <?php settings_fields('wmr_settings_group'); ?>
            <table class="form-table" id="wmr-rules-table">
                <thead>
                    <tr>
                        <th>Order <span title="Rules mit kleineren Zahlen werden zuerst geprüft. Spätere Rules überschreiben frühere." style="cursor: help;">🛈</span></th>
                        <th>Type <span title="Anwendbar auf Product ID, Category ID oder Shipping Class ID." style="cursor: help;">🛈</span></th>
                        <th>Ziel-IDs <span title="Mehrere IDs kommasepariert. Z.B. 12,45,78." style="cursor: help;">🛈</span></th>
                        <th>Quantity <span title="Ab welcher Quantity die Regel greift." style="cursor: help;">🛈</span></th>
                        <th>Discount (z.B. 0.5) <span title="Discount in Euro. Nur positive Werte in 0,50-Schritten." style="cursor: help;">🛈</span></th>
                        <th>Description <span title="Nur zur Info im Backend." style="cursor: help;">🛈</span></th>
                        <th>Active <span title="Nur aktive Rules werden angewendet." style="cursor: help;">🛈</span></th>
                        <th>Delete <span title="Wird beim Speichern entfernt." style="cursor: help;">🛈</span></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rules as $index => $rule) : ?>
                    <tr>
                        <td><input type="number" name="wmr_discount_rules[<?php echo $index; ?>][order]" value="<?php echo esc_attr($rule['order'] ?? 0); ?>"></td>
                        <td>
                            <select name="wmr_discount_rules[<?php echo $index; ?>][type]">
                                <option value="product" <?php selected($rule['type'], 'product'); ?>>Produkt</option>
                                <option value="category" <?php selected($rule['type'], 'category'); ?>>Kategorie</option>
                                <option value="shipping_class" <?php selected($rule['type'], 'shipping_class'); ?>>Versandklasse</option>
                            </select>
                        </td>
                        <td><input type="text" name="wmr_discount_rules[<?php echo $index; ?>][id]" value="<?php echo esc_attr($rule['id']); ?>"></td>
                        <td><input type="number" name="wmr_discount_rules[<?php echo $index; ?>][qty]" value="<?php echo esc_attr($rule['qty']); ?>"></td>
                        <td><input type="number" step="0.5" min="0" name="wmr_discount_rules[<?php echo $index; ?>][discount]" value="<?php echo esc_attr($rule['discount']); ?>"></td>
                        <td><input type="text" name="wmr_discount_rules[<?php echo $index; ?>][desc]" value="<?php echo esc_attr($rule['desc'] ?? ''); ?>"></td>
                        <td><input type="checkbox" name="wmr_discount_rules[<?php echo $index; ?>][enabled]" value="1" <?php checked(!empty($rule['enabled'])); ?>></td>
                        <td><input type="checkbox" name="wmr_discount_rules[<?php echo $index; ?>][delete]" value="1"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <button type="button" class="button" onclick="wmrAddRule()">+ Neue Regel</button>
            <?php submit_button(); ?>
        </form>
    </div>
    <script>
        let ruleIndex = <?php echo count($rules); ?>;
        function wmrAddRule() {
            const row = `
                <tr>
                    <td><input type="number" name="wmr_discount_rules[\${ruleIndex}][order]" value="0"></td>
                    <td><select name="wmr_discount_rules[\${ruleIndex}][type]">
                        <option value="product">Produkt</option>
                        <option value="category">Kategorie</option>
                        <option value="shipping_class">Versandklasse</option>
                    </select></td>
                    <td><input type="text" name="wmr_discount_rules[\${ruleIndex}][id]" placeholder="z.B. 12,34"></td>
                    <td><input type="number" name="wmr_discount_rules[\${ruleIndex}][qty]"></td>
                    <td><input type="number" step="0.5" min="0" name="wmr_discount_rules[\${ruleIndex}][discount]" placeholder="z.B. 0.5"></td>
                    <td><input type="text" name="wmr_discount_rules[\${ruleIndex}][desc]"></td>
                    <td><input type="checkbox" name="wmr_discount_rules[\${ruleIndex}][enabled]" value="1" checked></td>
                    <td><input type="checkbox" name="wmr_discount_rules[\${ruleIndex}][delete]" value="1"></td>
                </tr>`;
            document.querySelector('#wmr-rules-table tbody').insertAdjacentHTML('beforeend', row);
            ruleIndex++;
        }
    </script>
    <?php
}

add_action('woocommerce_before_calculate_totals', function($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    $rules = get_option('wmr_discount_rules', []);
    if (empty($rules)) return;

    usort($rules, fn($a, $b) => intval($a['order']) <=> intval($b['order']));

    foreach ($cart->get_cart() as $item) {
        $product = $item['data'];
        $qty = $item['quantity'];
        $product_id = $product->get_id();
        $categories = $product->get_category_ids();
        $shipping_class = $product->get_shipping_class_id();
        $original_price = $product->get_price();
        $final_price = $original_price;

        foreach ($rules as $rule) {
            if (empty($rule['enabled'])) continue;
            $ids = array_map('trim', explode(',', $rule['id']));
            $match = false;
            if ($rule['type'] === 'product' && in_array($product_id, $ids)) $match = true;
            if ($rule['type'] === 'category' && array_intersect($ids, $categories)) $match = true;
            if ($rule['type'] === 'shipping_class' && in_array($shipping_class, $ids)) $match = true;

            if ($match && $qty >= $rule['qty']) {
                $discount = floatval($rule['discount']);
                if ($discount > 0 && fmod($discount, 0.5) === 0.0) {
                    $final_price = max(0, $original_price - $discount);
                }
            }
        }

        if ($final_price !== $original_price) {
            $product->set_price($final_price);
            $product->add_meta_data('mengenrabatt_info', __('Quantitynrabatt angewendet', 'woocommerce'), true);
        }
    }
});

add_filter('woocommerce_get_item_data', function($item_data, $cart_item) {
    if (!empty($cart_item['data']) && $label = $cart_item['data']->get_meta('mengenrabatt_info')) {
        $item_data[] = [
            'name' => __('Hinweis', 'woocommerce'),
            'value' => $label,
        ];
    }
    return $item_data;
}, 10, 2);